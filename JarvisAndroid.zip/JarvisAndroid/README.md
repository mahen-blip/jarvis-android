# J.A.R.V.I.S. Android Starter

Native Android starter using Kotlin and Jetpack Compose. Includes an emerald HUD, local chat history, editable local memory, and offline utilities.

## Current capabilities
- Emerald/black HUD interface
- Local chat transcript persistence with Android SharedPreferences
- Editable memory stored locally
- Local clock/date tool
- Basic calculator for one binary operation, such as `12*8`, `15/3`, `7.5+2`
- Commands: `/help`, `/status`, `/time`, `/tools`
- No internet permission requested

## Important limitation
The assistant engine is rule-based, not a generative AI model. Arbitrary questions receive a transparent fallback response. Real AI requires a compatible on-device model or a secure backend API. Never put a private API key directly in an Android APK.

## Requirements
- Android Studio with Android SDK Platform 35
- JDK 17 (Android Studio's bundled JBR is normally suitable)
- Android 8.0 (API 26) or newer device/emulator

## Build and run
1. Extract `JarvisAndroid.zip`.
2. Open the extracted `JarvisAndroid` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Install Android SDK Platform 35 if prompted.
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Press **Run**.

To build an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio displays the APK path when finished.

## Project layout
- `app/src/main/java/com/mahen/jarvis/MainActivity.kt` — UI, offline logic, tools, persistence
- `app/src/main/AndroidManifest.xml` — app declaration; no internet permission
- `app/build.gradle.kts` — Android and Compose dependencies

## Next milestones
1. Replace preferences-based chat storage with Room and migrations.
2. Integrate an Android-compatible on-device language model; check RAM, storage, and license requirements.
3. Add speech recognition and text-to-speech with explicit permissions and clear online/offline behavior.
4. Add unit tests for calculator parsing, command routing, and memory persistence.
5. Add export/delete controls and a privacy screen.
