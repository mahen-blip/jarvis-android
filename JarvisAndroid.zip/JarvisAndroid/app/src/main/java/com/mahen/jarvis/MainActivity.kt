package com.mahen.jarvis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF050A08)
private val Panel = Color(0xFF0B1711)
private val Panel2 = Color(0xFF10251A)
private val Green = Color(0xFF39FF9A)
private val Muted = Color(0xFF83B69A)
private val White = Color(0xFFE8FFF0)
private const val PREFS = "jarvis_local"
private const val CHAT_KEY = "chat_json"
private const val MEMORY_KEY = "memory_text"

data class ChatMessage(val text: String, val fromUser: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
fun JarvisApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("CHAT") }
    var input by remember { mutableStateOf("") }
    var memory by remember { mutableStateOf(prefs.getString(MEMORY_KEY, "") ?: "") }
    var messages by remember { mutableStateOf(loadMessages(prefs.getString(CHAT_KEY, null))) }

    fun persistChat(list: List<ChatMessage>) {
        val arr = JSONArray()
        list.takeLast(150).forEach {
            arr.put(JSONObject().put("text", it.text).put("user", it.fromUser).put("time", it.time))
        }
        prefs.edit().putString(CHAT_KEY, arr.toString()).apply()
    }
    fun sendMessage(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val now = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val updated = (messages + ChatMessage(text, true, now) +
                ChatMessage(assistantReply(text, memory), false, now)).takeLast(150)
        messages = updated
        persistChat(updated)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, onPrimary = Bg, background = Bg, surface = Panel, onSurface = White, secondary = Muted
    )) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Header()
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                NavButton("CHAT", screen == "CHAT", Modifier.weight(1f)) { screen = "CHAT" }
                NavButton("TOOLS", screen == "TOOLS", Modifier.weight(1f)) { screen = "TOOLS" }
                NavButton("MEMORY", screen == "MEMORY", Modifier.weight(1f)) { screen = "MEMORY" }
            }
            Spacer(Modifier.height(12.dp))
            when (screen) {
                "CHAT" -> {
                    StatusStrip()
                    Spacer(Modifier.height(10.dp))
                    if (messages.isEmpty()) {
                        WelcomePanel { prompt -> input = prompt }
                        Spacer(Modifier.height(10.dp))
                    }
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) { items(messages) { MessageCard(it) } }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .border(1.dp, Green.copy(alpha = .45f), RoundedCornerShape(16.dp))
                            .background(Panel, RoundedCornerShape(16.dp)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BasicTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                            decorationBox = { inner ->
                                if (input.isEmpty()) Text("Transmit message...", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        )
                        IconButton(onClick = { sendMessage(input); input = "" }) {
                            Icon(Icons.Default.Send, "Send message", tint = Green)
                        }
                    }
                    Text("OFFLINE ENGINE • LOCAL STORAGE ONLY", color = Muted, fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 7.dp))
                }
                "TOOLS" -> ToolsScreen { result ->
                    val now = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                    val updated = (messages + ChatMessage(result, false, now)).takeLast(150)
                    messages = updated
                    persistChat(updated)
                    screen = "CHAT"
                }
                else -> MemoryScreen(memory, onSave = {
                    memory = it
                    prefs.edit().putString(MEMORY_KEY, it).apply()
                })
            }
        }
    }
}

@Composable
fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(52.dp).border(1.dp, Green, CircleShape).background(Panel2, CircleShape),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Memory, null, tint = Green, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("J.A.R.V.I.S.", color = Green, fontSize = 25.sp, fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace)
            Text("PERSONAL INTELLIGENCE SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 1.1.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("● ONLINE", color = Green, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("CORE v1.0", color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
fun StatusStrip() {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp))
        .border(1.dp, Green.copy(.2f), RoundedCornerShape(10.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        StatusValue("MODE", "LOCAL")
        StatusValue("MEMORY", "ENABLED")
        StatusValue("NETWORK", "NOT REQUIRED")
    }
}
@Composable
fun StatusValue(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun WelcomePanel(onPrompt: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
        .border(1.dp, Green.copy(.35f), RoundedCornerShape(14.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("SYSTEM READY, OPERATOR.", color = Green, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text("I am running in offline starter mode. Select a quick command to begin.", color = White, fontSize = 13.sp)
        listOf("/status", "/tools", "Help me plan my day").forEach { prompt ->
            Text(prompt, color = Green, modifier = Modifier.fillMaxWidth()
                .background(Panel2, RoundedCornerShape(8.dp)).clickable { onPrompt(prompt) }.padding(10.dp),
                fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
    }
}

@Composable
fun MessageCard(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 310.dp)
            .background(if (message.fromUser) Panel2 else Panel, RoundedCornerShape(13.dp))
            .border(1.dp, if (message.fromUser) Green.copy(.35f) else Muted.copy(.18f), RoundedCornerShape(13.dp))
            .padding(11.dp)) {
            Text(if (message.fromUser) "OPERATOR" else "J.A.R.V.I.S.",
                color = if (message.fromUser) Muted else Green, fontSize = 9.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(4.dp))
            Text(message.text, color = White, fontSize = 14.sp)
            Spacer(Modifier.height(5.dp))
            Text(message.time, color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.End))
        }
    }
}

@Composable
fun NavButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.background(if (selected) Panel2 else Panel, RoundedCornerShape(9.dp))
        .border(1.dp, if (selected) Green else Muted.copy(.2f), RoundedCornerShape(9.dp))
        .clickable(onClick = onClick).padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (selected) Green else Muted, fontWeight = FontWeight.Bold,
            fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun ToolsScreen(onResult: (String) -> Unit) {
    var expression by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("UTILITY BAY", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("Tools run locally. No network permission is requested.", color = Muted, fontSize = 12.sp)
        ToolCard("TIME / DATE", "Read the device clock") {
            onResult("LOCAL TIME: ${SimpleDateFormat("EEEE, dd MMM yyyy • HH:mm:ss", Locale.getDefault()).format(Date())}")
        }
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("CALCULATOR", color = Green, fontWeight = FontWeight.Bold)
            Text("Enter one arithmetic operation, e.g. 12 × 8", color = Muted, fontSize = 12.sp)
            OutlinedTextField(value = expression, onValueChange = { expression = it },
                label = { Text("Expression") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { onResult(calculate(expression)) }, modifier = Modifier.fillMaxWidth()) { Text("Calculate") }
        }
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("QUICK NOTE", color = Green, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = note, onValueChange = { note = it },
                label = { Text("Note text") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { if (note.isNotBlank()) onResult("NOTE: ${note.trim()}") },
                modifier = Modifier.fillMaxWidth()) { Text("Send note to chat") }
        }
    }
}

@Composable
fun ToolCard(title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
        .border(1.dp, Green.copy(.2f), RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Bolt, null, tint = Green)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = White, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun MemoryScreen(memory: String, onSave: (String) -> Unit) {
    var draft by remember(memory) { mutableStateOf(memory) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MEMORY CORE", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("Save details you want the local assistant to use in replies. Stored on this device.", color = Muted, fontSize = 12.sp)
        OutlinedTextField(value = draft, onValueChange = { draft = it },
            modifier = Modifier.fillMaxWidth().weight(1f), label = { Text("Operator memory") },
            placeholder = { Text("Example: I prefer concise explanations and step-by-step math help.") })
        Button(onClick = { onSave(draft) }, modifier = Modifier.fillMaxWidth()) { Text("SAVE MEMORY") }
        OutlinedButton(onClick = { draft = ""; onSave("") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.DeleteOutline, null)
            Spacer(Modifier.width(8.dp))
            Text("CLEAR MEMORY")
        }
        Text("Memory is stored in app preferences unless you clear app data or uninstall.", color = Muted, fontSize = 11.sp)
    }
}

fun assistantReply(input: String, memory: String): String {
    val text = input.trim()
    val lower = text.lowercase(Locale.ROOT)
    if (lower == "/status" || lower.contains("system status")) {
        return "SYSTEM STATUS: ONLINE\nMODE: OFFLINE STARTER\nCHAT: READY\nLOCAL MEMORY: ${if (memory.isBlank()) "EMPTY" else "AVAILABLE"}\nNETWORK: NOT USED\nAI MODEL: RULE-BASED RESPONSE ENGINE"
    }
    if (lower == "/tools") return "AVAILABLE TOOLS:\n• /status - show system status\n• /time - show local device time\n• /help - show commands\nOpen the TOOLS tab for calculator, clock, and quick notes."
    if (lower == "/time") return "LOCAL TIME: ${SimpleDateFormat("EEEE, dd MMM yyyy • HH:mm:ss", Locale.getDefault()).format(Date())}"
    if (lower == "/help" || lower == "help") {
        return "COMMANDS:\n/status  System status\n/time    Device time\n/tools   Tool list\n/help    This help message\n\nI am an offline starter, not a full language model yet."
    }
    if (lower.contains("hello") || lower == "hi" || lower.startsWith("hlo"))
        return "Hello, Operator. J.A.R.V.I.S. is online. What shall we work on?"
    if (lower.contains("who are you") || lower.contains("what are you"))
        return "I am J.A.R.V.I.S., your local assistant interface. This starter uses predefined logic and does not yet contain a generative AI model."
    if (lower.contains("remember") && memory.isNotBlank()) return "Your saved local memory says:\n$memory"
    if (lower.contains("offline"))
        return "Offline mode is active. The HUD, local chat history, memory, clock, and basic calculator work without internet. Open-ended AI reasoning requires a local model or an online API."
    if (lower.contains("thank")) return "You're welcome, Operator."
    return "Acknowledged, Operator.\n\nI received: \"$text\"\n\nThis starter uses a rule-based offline engine, so it cannot reason about arbitrary questions yet. Try /help, /status, or the TOOLS tab. A local language model can be integrated in a later milestone."
}

fun loadMessages(json: String?): List<ChatMessage> {
    if (json.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val obj = arr.getJSONObject(i)
            ChatMessage(obj.optString("text"), obj.optBoolean("user"), obj.optString("time"))
        }
    } catch (_: Exception) { emptyList() }
}

fun calculate(source: String): String {
    val expr = source.trim().replace("×", "*").replace("÷", "/").replace(" ", "")
    if (expr.isBlank()) return "CALCULATOR: Enter an expression first."
    val pattern = Regex("""^(-?\d+(?:\.\d+)?)([+\-*/])(-?\d+(?:\.\d+)?)$""")
    val match = pattern.matchEntire(expr)
        ?: return "CALCULATOR: Use one operation, e.g. 12*8, 15/3, or 7.5+2."
    val a = match.groupValues[1].toDoubleOrNull() ?: return "Invalid first number."
    val op = match.groupValues[2]
    val b = match.groupValues[3].toDoubleOrNull() ?: return "Invalid second number."
    if (op == "/" && b == 0.0) return "ERROR: Division by zero is undefined."
    val result = when (op) { "+" -> a + b; "-" -> a - b; "*" -> a * b; else -> a / b }
    val shown = if (result.isFinite()) String.format(Locale.US, "%.8f", result).trimEnd('0').trimEnd('.') else result.toString()
    return "CALCULATION: $a $op $b = $shown"
}
